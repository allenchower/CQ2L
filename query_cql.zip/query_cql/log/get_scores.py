import os
import numpy as np
from tensorboard.backend.event_processing import event_accumulator

env_list = [
    "hopper-medium-v2",
    "halfcheetah-medium-v2",
    "walker2d-medium-v2",
    "hopper-medium-replay-v2",
    "halfcheetah-medium-replay-v2",
    "walker2d-medium-replay-v2",
    "hopper-medium-expert-v2",
    "halfcheetah-medium-expert-v2",
    "walker2d-medium-expert-v2",
    "antmaze-umaze-v2",
    "antmaze-umaze-diverse-v2",
    "antmaze-medium-play-v2",
    "antmaze-medium-diverse-v2",
    "antmaze-large-play-v2",
    "antmaze-large-diverse-v2",
]

root_logdir = "."  # ← 替换成你的实际路径

def get_last_normalized_eval_score(log_path):
    try:
        ea = event_accumulator.EventAccumulator(log_path)
        ea.Reload()
        if 'normalized_eval_score' in ea.Tags().get('scalars', []):
            scalar_events = ea.Scalars('normalized_eval_score')
            if scalar_events:
                return scalar_events[-1].value  # 取最后一个
    except Exception as e:
        print(f"[Warning] Failed to read {log_path}: {e}")
    return None

results = {}

for env in env_list:
    scores = []
    for seed in range(5):
        logdir = os.path.join(root_logdir, env, f"{seed}")
        if not os.path.exists(logdir):
            print(f"[Info] Skip: {logdir} does not exist.")
            continue
        for file in os.listdir(logdir):
            if file.startswith("events.out.tfevents"):
                filepath = os.path.join(logdir, file)
                score = get_last_normalized_eval_score(filepath)
                if score is not None:
                    scores.append(score)
                break  # 假设每个 seed 目录只有一个事件文件
    if scores:
        mean = np.mean(scores)
        std = np.std(scores)
        results[env] = {
            "mean": mean,
            "std": std,
            "all_scores": scores
        }
    else:
        results[env] = {
            "mean": None,
            "std": None,
            "all_scores": []
        }

# 输出结果
for env, res in results.items():
    print(f"{env:30} | mean: {res['mean']:.2f} | std: {res['std']:.2f} | scores: {res['all_scores']} | {res['mean']:.1f} ± {res['std']:.1f}")
